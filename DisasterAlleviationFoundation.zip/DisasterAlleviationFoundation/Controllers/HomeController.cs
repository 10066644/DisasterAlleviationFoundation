using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DisasterAlleviationFoundation.Models;
using System.Diagnostics;

namespace DisasterAlleviationFoundation.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var stats = new
            {
                TotalReports = await _context.DisasterReports.CountAsync(),
                TotalDonations = await _context.Donations.CountAsync(),
                TotalVolunteers = await _context.Volunteers.CountAsync(),
                RecentReports = await _context.DisasterReports.OrderByDescending(r => r.ReportedDate).Take(5).ToListAsync(),
                RecentDonations = await _context.Donations.OrderByDescending(d => d.DonationDate).Take(5).ToListAsync()
            };
            ViewBag.Stats = stats;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}