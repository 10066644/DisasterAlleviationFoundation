﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DisasterAlleviationFoundation.Models;

namespace DisasterAlleviationFoundation.Controllers
{
    [Authorize]
    public class VolunteersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VolunteersController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(Volunteer volunteer)
        {
            if (ModelState.IsValid)
            {
                // Manually handle null UserId
                var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier);
                volunteer.UserId = userIdClaim != null ? userIdClaim.Value : null;
                _context.Add(volunteer);
                await _context.SaveChangesAsync();
                return RedirectToAction("BrowseTasks");
            }
            return View(volunteer);
        }

        public async Task<IActionResult> BrowseTasks()
        {
            var tasks = await _context.VolunteerTasks
                .Where(t => t.VolunteerId == null)
                .ToListAsync();
            return View(tasks);
        }

        [HttpPost]
        public async Task<IActionResult> AssignTask(int taskId)
        {
            var task = await _context.VolunteerTasks.FindAsync(taskId);
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier);
            var volunteer = userIdClaim != null
                ? await _context.Volunteers.FirstOrDefaultAsync(v => v.UserId == userIdClaim.Value)
                : null;

            if (task != null && volunteer != null && task.VolunteerId == null)
            {
                task.VolunteerId = volunteer.Id;
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("BrowseTasks");
        }
    }
}