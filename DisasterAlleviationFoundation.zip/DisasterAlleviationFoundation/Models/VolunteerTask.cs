﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models
{
    public class VolunteerTask
    {
        public int Id { get; set; }
        [Required]
        public string? Description { get; set; }
        [Required]
        public string? Location { get; set; }
        [Required]
        public DateTime ScheduledDate { get; set; }
        public int? VolunteerId { get; set; }
        public Volunteer? Volunteer { get; set; }
    }
}