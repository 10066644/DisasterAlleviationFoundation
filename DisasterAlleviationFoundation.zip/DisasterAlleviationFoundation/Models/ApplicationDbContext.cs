﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace DisasterAlleviationFoundation.Models
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<DisasterReport> DisasterReports { get; set; } = null!;
        public DbSet<Donation> Donations { get; set; } = null!;
        public DbSet<Volunteer> Volunteers { get; set; } = null!;
        public DbSet<VolunteerTask> VolunteerTasks { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<DisasterReport>().HasData(
                new DisasterReport { Id = 1, Description = "Flood in Miami", Location = "Miami", Type = "Flood", ReportedDate = DateTime.Now.AddDays(-1) }
            );
            builder.Entity<Donation>().HasData(
                new Donation { Id = 1, ResourceType = "Food", Quantity = 50, Destination = "Miami", DonationDate = DateTime.Now.AddDays(-2), Distributed = false }
            );
            builder.Entity<Volunteer>().HasData(
                new Volunteer { Id = 1, Name = "John Doe", Skills = "Logistics", Availability = "Weekends" }
            );
            builder.Entity<VolunteerTask>().HasData(
                new VolunteerTask { Id = 1, Description = "Distribute Supplies", Location = "Miami", ScheduledDate = DateTime.Now.AddDays(1) }
            );
        }
    }
}