﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models
{
    public class DisasterReport
    {
        public int Id { get; set; }
        public string? UserId { get; set; }
        [Required]
        public string? Description { get; set; }
        [Required]
        public string? Location { get; set; }
        public DateTime ReportedDate { get; set; } = DateTime.Now;
        [Required]
        public string? Type { get; set; }
    }
}