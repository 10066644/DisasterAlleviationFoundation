﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models
{
    public class Volunteer
    {
        public int Id { get; set; }
        public string? UserId { get; set; }
        [Required]
        public string? Name { get; set; }
        [Required]
        public string? Skills { get; set; }
        [Required]
        public string? Availability { get; set; }
    }
}