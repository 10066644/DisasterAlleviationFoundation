﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models
{
    public class Donation
    {
        public int Id { get; set; }
        public string? UserId { get; set; }
        [Required]
        public string? ResourceType { get; set; }
        [Required]
        public int Quantity { get; set; }
        [Required]
        public string? Destination { get; set; }
        public DateTime DonationDate { get; set; } = DateTime.Now;
        public bool Distributed { get; set; }
    }
}